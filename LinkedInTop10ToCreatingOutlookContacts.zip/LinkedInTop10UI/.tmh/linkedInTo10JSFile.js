const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
  // פותחים דפדפן חדש
  const browser = await puppeteer.launch();
  const page = await browser.newPage();

  // נכנסים לדף החיפוש של LinkedIn
  await page.goto('https://www.linkedin.com/search/results/people/?keywords=software%20engineer');

  // מציגים את כל תוצאות החיפוש בקונסולה
  const searchResults = await page.$$eval('div.search-result__info');

  // יצירת מערך לקבלת נתוני הפרופילים
  const profiles = [];

  for (let i = 0; i < searchResults.length; i++) {
    // משיגים את שם המשתמש
    const nameElement = await searchResults[i].$('.actor-name');
    profile.name = await page.evaluate(name => name.textContent.trim(), nameElement);

    // משיגים את התפקיד והחברה
    const infoElements = await searchResults[i].$$('.subline-level-1');
    if (infoElements.length > 1) {
      profile.jobTitle = await page.evaluate(title => title.textContent.trim(), infoElements[0]);
      profile.companyName = await page.evaluate(company => company.textContent.trim(), infoElements[1]);
    } else {
      console.warn(`Missing job title or company name for search result #${i}`);
    }

    // משיגים את משך הזמן שהמשתמש עובד בחברה הנוכחית
    const timeElement = await searchResults[i].$('.relative-time');
    profile.workExperience = await page.evaluate(time => time.textContent.trim(), timeElement);

    // משיגים את ה-URL לפרופיל המלא של המשתמש
    const linkElement = await searchResults[i].$('a');
    profile.profileURL = await page.evaluate(link => link.href, linkElement);

    // מוסיפים את הפרופיל למערך
    profiles.push({ name, headline, location, profileURL });
  }

  // כותבים את נתוני הפרופילים לקובץ JSON
  fs.writeFileSync('profiles.json', JSON.stringify(profiles));

  // ייבא את הקובץ עם הפרופילים שנוצר על ידי הקוד הראשון
  const profilesData = fs.readFileSync('profiles.json');
  const profilesForOutlook = JSON.parse(profilesData);
  // פותחים דף חדש עם OUTLOOK ONLINE
  const pageForOutlook = await browser.newPage();
  await pageForOutlook.goto('https://outlook.office.com/people/');
  // await pageForOutlook.goto('https://outlook.office.com/');
  await pageForOutlook.waitForSelector('#loginfmt');
  await pageForOutlook.type('#loginfmt', 'your email');
  await pageForOutlook.click('#idSIButton9');
  await pageForOutlook.waitForSelector('#passwd');
  await pageForOutlook.type('#passwd', 'your password');
  await pageForOutlook.click('#idSIButton9');
  await pageForOutlook.waitForSelector('button[title="New Contact"]');

  // מוסיפים אנשי קשר חדשים לפי פרופילים בקובץ
   for (let i = 0; i < profilesForOutlook.length; i++) {
     const profile = profilesForOutlook[i];

     // לוחץ על הכפתור ליצירת איש קשר חדש
     await pageForOutlook.click('button[title="New Contact"]');

     // מעתיק את שם המשתמש לשדה "שם פרטי"
     await pageForOutlook.type('#firstName', profile.name.split(' ')[0]);

     // מעתיק את שם המשתמש לשדה "שם משתמש נוסף"
     await pageForOutlook.type('#lastName', profile.name.split(' ')[1]);

     // מעתיק את התפקיד לשדה "עמוד עבודה"
     await pageForOutlook.type('#JobTitle', profile.jobTitle);

     // מעתיק את שם החברה לשדה "חברה"
     await pageForOutlook.type('#CompanyName', profile.companyName);

      // מעתיק את משך הזמן שהמשתמש עובד בחברה הנוכחית לשדה "פירוט משרה"
      await pageForOutlook.type('#Notes', profile.workExperience);

      // מעתיק את ה-URL לפרופיל המלא לשדה "אתר אינטרנט"
      await pageForOutlook.type('#WebSite', profile.profileURL);

      // לוחץ על הכפתור לשמירת איש הקשר
      await pageForOutlook.click('button[title="Save"]');

      // ממתין לפעולה של שמירת איש הקשר
      await pageForOutlook.waitForNavigation({ waitUntil: 'networkidle0' });


  // סוגרים את הדפדפן
  await browser.close();
})();
