const puppeteer = require('puppeteer');
const fs = require('fs');
const dotenv = require('dotenv');

(async () => {
  try {
    // Open a new browser
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    // Here you have to change to the profession you want to search for
    const profession = 'software engineer';

    // Displaying the LinkedIn search page and searching for the desired profession
    await page.goto(`https://www.linkedin.com/search/results/people/?keywords=${profession}`);

  // error checking
    const error = await page.$('.global-alert-queue');
    if (error !== null) {
      throw new Error('הדף לא נטען כראוי או אירעה שגיאה בזמן הפעולה של הקוד.');
    }

    // display all search results in the console
    const searchResults = await page.$$('div.search-result__info');

    // Creating an array to receive the profile data
    const profiles = [];

    for (let i = 0; i < searchResults.length; i++) {
      // Create an object for the current profile
      const profile = {};
      // Getting the name
      const nameElement = await searchResults[i].$('.actor-name');
      profile.name = await page.evaluate(name => name.textContent.trim(), nameElement);

      // Get the role and the company name
      const infoElements = await searchResults[i].$$('.subline-level-1');
      if (infoElements.length > 1) {
        profile.jobTitle = await page.evaluate(el => el.textContent.trim(), infoElements[0]);
        profile.companyName = await page.evaluate(el => el.textContent.trim(), infoElements[1]);
      } else {
        console.warn(`Missing job title or company name for search result #${i}`);
      }

      // Getting the duration of time the user in the work at the current company
      const timeElement = await searchResults[i].$('.relative-time');
      profile.durationOfWork = await page.evaluate(time => time.textContent.trim(), timeElement);

      // Getting the direct link URL to the user's profile
      const linkElement = await searchResults[i].$$('a');
      profile.profileURL = await page.evaluate(link => link.href, linkElement);

      // Addding the profile to the array
      profiles.push(profile);
    }
    // Writing the profile data to a text file
    fs.writeFileSync('profiles.txt', JSON.stringify(profiles));

    const config = dotenv.config().parsed;
    // Import the file with the profiles from the previous step
    const profilesData = fs.readFileSync('profiles.txt', 'utf-8');
    const profilesForOutlook = JSON.parse(profilesData);

    const browserForOutlook = await puppeteer.launch({ headless: false });

    // Open a new page - Outlook Online
    const pageForOutlook = await browserForOutlook.newPage();

    await pageForOutlook.goto('https://outlook.office.com/people/');
    // Waiting for the page to load and log in to the account
    await pageForOutlook.waitForSelector('#loginfmt');
    await pageForOutlook.type('#loginfmt', 'your email');
    await pageForOutlook.click('#idSIButton9');
    await pageForOutlook.waitForSelector('#passwd');
    await pageForOutlook.type('#passwd', 'your password');
    await pageForOutlook.click('#idSIButton9');
    await pageForOutlook.waitForNavigation();
    await pageForOutlook.waitForSelector('button[title="New Contact"]');

    // Adding new contacts according to profiles in the text file
    for (let i = 0; i < profilesForOutlook.length; i++) {

      const profile = profilesForOutlook[i];

     // Clicking the button to create a new contact
     await pageForOutlook.click('button[title="New Contact"]');

     // The timer for selecting the first field - name
     await pageForOutlook.waitForSelector('input[name="First"]');

     // copies the username to the "full name" field
     const [firstName, lastName] = profile.name.split(' ');
      await pageForOutlook.type('input[name="First"]', firstName);
      await pageForOutlook.type('input[name="Last"]', lastName);

    //I noticed it too late, I didn't have enough time to add the clicking step to open the options for -->
    // adding the job information and the link to a personal website

    // Copies the role to the "Title" field
    if (profile.jobTitle) {
       await pageForOutlook.type('#JobTitle', profile.jobTitle);
     }
      // Copies the full profile URL to the "Website" field
      if (profile.profileURL) {
        await pageForOutlook.type('#WebSite', profile.profileURL);
      }

      // Clicks the button to save the contact
      await pageForOutlook.click('button[title="Save"]');

      // Waiting for contact save action
      await pageForOutlook.waitForNavigation({ waitUntil: 'networkidle0' });

    }
  // Closing the browser
  await browser.close();
})();
